<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="PrototypeSprites" tilewidth="64" tileheight="64" tilecount="104" columns="26">
 <image source="PrototypeLightAndDark.png" width="1664" height="256"/>
</tileset>
